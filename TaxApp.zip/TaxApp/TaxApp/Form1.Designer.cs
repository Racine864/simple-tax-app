﻿namespace TaxApp
{
    partial class FormTaxApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtDue = new TextBox();
            txtTaxPercent = new Label();
            button1 = new Button();
            txtAmount = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Book Antiqua", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(42, 27);
            label1.Name = "label1";
            label1.Size = new Size(138, 23);
            label1.TabIndex = 0;
            label1.Text = "Tax Calculator";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ImageAlign = ContentAlignment.MiddleLeft;
            label2.Location = new Point(42, 81);
            label2.Name = "label2";
            label2.Size = new Size(83, 16);
            label2.TabIndex = 1;
            label2.Text = "Total Amount";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ImageAlign = ContentAlignment.MiddleLeft;
            label3.Location = new Point(42, 126);
            label3.Name = "label3";
            label3.Size = new Size(88, 16);
            label3.TabIndex = 2;
            label3.Text = "Tax Percentage";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ImageAlign = ContentAlignment.BottomLeft;
            label4.Location = new Point(42, 167);
            label4.Name = "label4";
            label4.Size = new Size(60, 16);
            label4.TabIndex = 3;
            label4.Text = "Total Due";
            // 
            // txtDue
            // 
            txtDue.Enabled = false;
            txtDue.Location = new Point(141, 164);
            txtDue.Name = "txtDue";
            txtDue.Size = new Size(60, 22);
            txtDue.TabIndex = 5;
            // 
            // txtTaxPercent
            // 
            txtTaxPercent.AutoSize = true;
            txtTaxPercent.BackColor = Color.DarkBlue;
            txtTaxPercent.Font = new Font("Book Antiqua", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            txtTaxPercent.ForeColor = Color.FromArgb(192, 192, 255);
            txtTaxPercent.Location = new Point(143, 130);
            txtTaxPercent.Name = "txtTaxPercent";
            txtTaxPercent.Size = new Size(37, 17);
            txtTaxPercent.TabIndex = 6;
            txtTaxPercent.Text = "7.5%";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 0, 192);
            button1.ForeColor = Color.FromArgb(192, 192, 255);
            button1.Location = new Point(62, 215);
            button1.Name = "button1";
            button1.Size = new Size(94, 34);
            button1.TabIndex = 7;
            button1.Text = "Calculate";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(139, 78);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(62, 22);
            txtAmount.TabIndex = 8;
            // 
            // FormTaxApp
            // 
            AutoScaleDimensions = new SizeF(7F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 192, 255);
            ClientSize = new Size(213, 273);
            Controls.Add(txtAmount);
            Controls.Add(button1);
            Controls.Add(txtTaxPercent);
            Controls.Add(txtDue);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Book Antiqua", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "FormTaxApp";
            Text = "TaxApp";
        
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox txtDue;
        private Label txtTaxPercent;
        private Button button1;
        private TextBox txtAmount;
    }
}
