namespace TaxApp
{
    public partial class FormTaxApp : Form
    {
        public FormTaxApp()
        {
            InitializeComponent();
        }

    

        private void button1_Click(object sender, EventArgs e)
        {
            string invalue;
            double purchaseAmt, percent, ans;

            while (double.TryParse(txtAmount.Text, out purchaseAmt) == false)
            {
                Console.Beep();
                MessageBox.Show("Answer must be numeric");
                txtAmount.Text = "0.0";
                txtAmount.Focus();
            }

            invalue = txtAmount.Text;
            invalue= invalue.Remove(invalue.Length-1,1);
            percent = double.Parse(invalue)/100;
            ans = (purchaseAmt * percent) + purchaseAmt;
            txtDue.Text = string.Format("{0:C}", ans).ToString();
        }
    }
}
