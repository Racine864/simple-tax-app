﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS_IncomeTaxWages
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Console.Beep();
            DialogResult iExit;
            iExit = MessageBox.Show("Confirmation", "Income Tax And Wages", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            txtEmployee.Text = "";
            txtEmployer.Text = "";
            txtGrossPayment.Text = "";
            txtGrossPaymentDate.Text = "";
            txtNICode.Text = "";
            txtTaxablePayment.Text = "";
            txtNetPay.Text = "";
            txtTaxDeduction.Text = "";
            txtGrossPayment.Text = "";
            txtGrossPaymentDate.Text = "";
            txtReference.Text = "";
            txtGrossPayment.Text = "";
            txtTaxDeduction.Text = "";
            txtNetPay.Text = "";
            txtNICode.Text = "";
            cobPayment.Text = "";
            cobNICode.Text = "";
            cobTaxCode.Text = "";
            cobTaxPeriod.Text = "";

            Random random = new Random();
            txtReference.Text = Convert.ToString(random.Next(15242,9845213));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random random = new Random();
            txtReference.Text = Convert.ToString(random.Next(15242, 9845213));

            DateTime TDay = DateTime.Today;
            txtGrossPaymentDate.Text = TDay.ToString("d");

            cobPayment.Items.Add(1200);
            cobPayment.Items.Add(1700);
            cobPayment.Items.Add(2200);
            cobPayment.Items.Add(2700);
            cobPayment.Items.Add(3200);
            cobPayment.Items.Add(4500);

            cobTaxPeriod.Items.Add("Jan");
            cobTaxPeriod.Items.Add("Feb");
            cobTaxPeriod.Items.Add("Mar");
            cobTaxPeriod.Items.Add("Apr");
            cobTaxPeriod.Items.Add("May");
            cobTaxPeriod.Items.Add("Jun");
            cobTaxPeriod.Items.Add("Jul");
            cobTaxPeriod.Items.Add("Aug");
            cobTaxPeriod.Items.Add("Sep");
            cobTaxPeriod.Items.Add("Oct");
            cobTaxPeriod.Items.Add("Nov");
            cobTaxPeriod.Items.Add("Dec");

            cobTaxCode.Items.Add("TC00117");
            cobTaxCode.Items.Add("TC00217");
            cobTaxCode.Items.Add("TC00317");
            cobTaxCode.Items.Add("TC00417");
            cobTaxCode.Items.Add("TC00517");
            cobTaxCode.Items.Add("TC00617");
            cobTaxCode.Items.Add("TC00717");

            cobNICode.Items.Add("NIV51852");
            cobNICode.Items.Add("NIV52852");
            cobNICode.Items.Add("NIV53852");
            cobNICode.Items.Add("NIV54852");
            cobNICode.Items.Add("NIV55852");
            cobNICode.Items.Add("NIV56852");
            cobNICode.Items.Add("NIV57852");
            cobNICode.Items.Add("NIV58852");
        }

        private void btnIncomeTax_Click(object sender, EventArgs e)
        {
            Double q, p, d, g, Taxdeducted, wagespaid, pay;
            pay = 1200;
            q= Convert.ToDouble(cobPayment.Text);

            if (q <= 1200) { 
                txtGrossPayment.Text = Convert.ToString(q);
                txtTaxablePayment.Text = Convert.ToString(q-pay);

                p = Convert.ToDouble(txtTaxablePayment.Text);
                Taxdeducted = (p * 0) / 100;
                txtTaxDeduction.Text = Convert.ToString(Taxdeducted);
                txtNotTaxed.Text = Convert.ToString( pay);
                g = Convert.ToDouble(txtGrossPayment.Text);
                d = Convert.ToDouble(txtTaxDeduction.Text);

                wagespaid = g - d;
                txtNetPay.Text = Convert.ToString(wagespaid);

                txtGrossPayment.Text = string.Format("{0:C}", g);
                txtTaxDeduction.Text = string.Format("{0:C}", d);
                txtNetPay.Text = string.Format("{0:C}", wagespaid);
            }

            else if (q <= 1700)
            {
                txtGrossPayment.Text = Convert.ToString(q);
                txtTaxablePayment.Text = Convert.ToString(q - pay);

                p = Convert.ToDouble(txtTaxablePayment.Text);
                Taxdeducted = (p * 20) / 100;
                txtTaxDeduction.Text = Convert.ToString(Taxdeducted);
                txtNotTaxed.Text = Convert.ToString(pay);
                g = Convert.ToDouble(txtGrossPayment.Text);
                d = Convert.ToDouble(txtTaxDeduction.Text);

                wagespaid = g - d;
                txtNetPay.Text = Convert.ToString(wagespaid);

                txtGrossPayment.Text = string.Format("{0:C}", g);
                txtTaxDeduction.Text = string.Format("{0:C}", d);
                txtNetPay.Text = string.Format("{0:C}", wagespaid);
            }

            else if (q <= 2200)
            {
                txtGrossPayment.Text = Convert.ToString(q);
                txtTaxablePayment.Text = Convert.ToString(q - pay);

                p = Convert.ToDouble(txtTaxablePayment.Text);
                Taxdeducted = (p * 25) / 100;
                txtTaxDeduction.Text = Convert.ToString(Taxdeducted);
                txtNotTaxed.Text = Convert.ToString(pay);
                g = Convert.ToDouble(txtGrossPayment.Text);
                d = Convert.ToDouble(txtTaxDeduction.Text);

                wagespaid = g - d;
                txtNetPay.Text = Convert.ToString(wagespaid);

                txtGrossPayment.Text = string.Format("{0:C}", g);
                txtTaxDeduction.Text = string.Format("{0:C}", d);
                txtNetPay.Text = string.Format("{0:C}", wagespaid);
            }

            else if (q <= 2700)
            {
                txtGrossPayment.Text = Convert.ToString(q);
                txtTaxablePayment.Text = Convert.ToString(q - pay);

                p = Convert.ToDouble(txtTaxablePayment.Text);
                Taxdeducted = (p * 30.2) / 100;
                txtTaxDeduction.Text = Convert.ToString(Taxdeducted);
                txtNotTaxed.Text = Convert.ToString(pay);
                g = Convert.ToDouble(txtGrossPayment.Text);
                d = Convert.ToDouble(txtTaxDeduction.Text);

                wagespaid = g - d;
                txtNetPay.Text = Convert.ToString(wagespaid);

                txtGrossPayment.Text = string.Format("{0:C}", g);
                txtTaxDeduction.Text = string.Format("{0:C}", d);
                txtNetPay.Text = string.Format("{0:C}", wagespaid);
            }

            else if (q <= 3200)
            {
                txtGrossPayment.Text = Convert.ToString(q);
                txtTaxablePayment.Text = Convert.ToString(q - pay);

                p = Convert.ToDouble(txtTaxablePayment.Text);
                Taxdeducted = (p * 35.3) / 100;
                txtTaxDeduction.Text = Convert.ToString(Taxdeducted);
                txtNotTaxed.Text = Convert.ToString(pay);
                g = Convert.ToDouble(txtGrossPayment.Text);
                d = Convert.ToDouble(txtTaxDeduction.Text);

                wagespaid = g - d;
                txtNetPay.Text = Convert.ToString(wagespaid);

                txtGrossPayment.Text = string.Format("{0:C}", g);
                txtTaxDeduction.Text = string.Format("{0:C}", d);
                txtNetPay.Text = string.Format("{0:C}", wagespaid);
            }

            else if (q >= 3200)
            {
                txtGrossPayment.Text = Convert.ToString(q);
                txtTaxablePayment.Text = Convert.ToString(q - pay);

                p = Convert.ToDouble(txtTaxablePayment.Text);
                Taxdeducted = (p * 37.7) / 100;
                txtTaxDeduction.Text = Convert.ToString(Taxdeducted);
                txtNotTaxed.Text = Convert.ToString(pay);
                g = Convert.ToDouble(txtGrossPayment.Text);
                d = Convert.ToDouble(txtTaxDeduction.Text);

                wagespaid = g - d;
                txtNetPay.Text = Convert.ToString(wagespaid);

                txtGrossPayment.Text = string.Format("{0:C}", g);
                txtTaxDeduction.Text = string.Format("{0:C}", d);
                txtNetPay.Text = string.Format("{0:C}", wagespaid);
            }
        }
    }
}
